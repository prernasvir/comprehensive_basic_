package test;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class ProductNavigationTest {
    WebDriver driver;

    @BeforeTest
    public void setup() {
        System.setProperty("webdriver.chrome.driver", "//G:/Farmington/IT/Cognizant/Others/Automation/Drivers/chromedriver.exe");
        driver = new ChromeDriver();
    }

    @Test
    public void testProductNavigation() throws InterruptedException {
        driver.get("https://www.automationanywhere.com/");
        Thread.sleep(5000);
        WebElement acceptCookiesButton = driver.findElement(By.id("onetrust-accept-btn-handler")); // Replace with the actual ID or other selector
        acceptCookiesButton.click();
        Actions actions = new Actions(driver);

        WebElement productsMenu = driver.findElement(By.xpath("//a[text()='Products']"));
        actions.moveToElement(productsMenu).build().perform();

        JavascriptExecutor js = (JavascriptExecutor) driver;
        
        js.executeScript("arguments[0].dispatchEvent(new MouseEvent('mouseover', {bubbles: true, cancelable: true}));", productsMenu);

        
        Thread.sleep(5000);

        
        WebElement processDiscoveryLink = driver.findElement(By.xpath("//a[contains(text(), 'Process Discovery')]"));
        processDiscoveryLink.click();

        String currentUrl = driver.getCurrentUrl();
        String expectedUrl = "https://www.automationanywhere.com/products/process-discovery";
        Assert.assertEquals(currentUrl, expectedUrl, "URL does not match expected.");
    }

    @AfterTest
    public void tearDown() {
        driver.quit();
    }
}
